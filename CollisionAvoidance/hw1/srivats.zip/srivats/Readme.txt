3 Agents
--------

Distance horizon = 10 m
Time horizon= 4 sec

8 Agents 
--------

Distance horizon= 10 m
Time horizon= 4 sec

Crossing Agents
---------------

Distance horizon= 12
Time horizon= 7